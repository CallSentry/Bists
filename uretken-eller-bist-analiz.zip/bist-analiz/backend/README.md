# Üretken Eller BIST Analiz — Backend Kurulum Rehberi

Bu klasördeki kod hiç test edilmemiş bir ortamda (bu sohbetin çalıştığı
sanal makinede internet erişimi yok) yazıldı; borsapy'nin güncel
dokümantasyonuna göre hazırlandı ama ilk çalıştırmada küçük hatalar
çıkması olası. Aşağıdaki adımları takip ederken bir hata görürsen,
hata mesajını bana yapıştır, birlikte düzeltiriz.

## 1. Yerelde deneme (opsiyonel ama önerilir)

Eğer bir bilgisayarda Python kuruluysa, önce burada deneyebilirsin:

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

python fetch_data.py            # bist_data.db dosyasını oluşturur, birkaç dakika sürebilir
python api.py                   # http://localhost:8000/api/stocks adresini tarayıcıda aç
```

`fetch_data.py` tüm BIST şirketleri için tek tek istek attığı için ilk
çalıştırma **10-20 dakika** sürebilir. Bu normal.

## 2. GitHub'a yükleme

1. github.com'da ücretsiz hesap aç (yoksa).
2. Yeni bir repository oluştur, örneğin `uretken-eller-bist`.
3. Bu `backend` klasörünü (ve az sonra oluşturacağımız `frontend`
   klasörünü) o repository'ye yükle. GitHub'ın web arayüzünden
   "Add file → Upload files" ile sürükle-bırak yapabilirsin, komut
   satırı gerekmez.

## 3. Backend'i Render'a deploy etme

1. [render.com](https://render.com) adresine GitHub hesabınla giriş yap.
2. **New +** → **Web Service** seç, az önce yüklediğin repo'yu bağla.
3. Ayarlar:
   - **Root Directory:** `backend`
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn api:app`
   - **Instance Type:** Free
4. Deploy'a bas. Birkaç dakika sonra sana `https://senin-servisin.onrender.com`
   gibi bir adres verecek — bunu not al, frontend'de kullanacağız.

**Önemli:** Bu adımdan sonra veritabanı boş olacak, çünkü
`fetch_data.py` henüz çalışmadı. Bunu bir sonraki adımda otomatikleştiriyoruz.

## 4. Günlük veri toplamayı otomatikleştirme (Cron Job)

1. Render panelinde **New +** → **Cron Job** seç, aynı repo'yu bağla.
2. Ayarlar:
   - **Root Directory:** `backend`
   - **Build Command:** `pip install -r requirements.txt`
   - **Command:** `python fetch_data.py`
   - **Schedule:** `30 15 * * 1-5` (Türkiye saatiyle hafta içi ~18:30,
     BIST kapanışından sonra — Render UTC kullanır, bu yüzden 15:30 UTC)
3. Kaydet. İlk çalıştırmayı manuel tetikleyebilirsin ("Trigger Run")
   böylece veritabanı hemen dolar, web servisi de onu kullanmaya başlar.

**Not:** Cron Job ve Web Service'in aynı veritabanı dosyasını
paylaşabilmesi için ikisinin de aynı "persistent disk"e bağlı olması
gerekir. Render'ın ücretsiz katmanında disk kalıcılığı sınırlı
olabilir — eğer veritabanı sıfırlanırsa, bunun yerine ücretsiz bir
Postgres (örn. Neon veya Supabase) kullanmamız gerekebilir. İlk
denemede sorun çıkarsa haber ver, o versiyona geçelim.

## 5. Frontend'i Vercel'e deploy etme

Frontend adımlarını `frontend/README.md` dosyasında bulacaksın.
