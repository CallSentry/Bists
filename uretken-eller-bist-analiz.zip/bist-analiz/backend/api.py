"""
Flask API — SQLite'a önceden çekilmiş BIST verilerini frontend'e sunar.

Bu servis borsapy'ye HİÇBİR istek atmaz; sadece fetch_data.py'nin
günlük olarak doldurduğu bist_data.db dosyasını okur. Bu sayede hızlı
çalışır ve harici veri kaynağının limitlerinden etkilenmez.
"""

import sqlite3

from flask import Flask, jsonify, request
from flask_cors import CORS

from indicators import sma, rsi, macd, interpret_short_term, interpret_long_term

DB_PATH = "bist_data.db"

app = Flask(__name__)
CORS(app)  # geliştirme için tüm originlere izin; production'da domain'e kısıtlayın


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


RANGE_DAYS = {"1A": 30, "3A": 90, "1Y": 365}


@app.get("/api/stocks")
def list_stocks():
    """Tüm hisselerin özet bilgisini döndürür (izleme listesi + ticker tape için)."""
    conn = get_connection()
    rows = conn.execute(
        "SELECT symbol, name, sector, last_price, prev_close, change_pct, updated_at FROM stocks ORDER BY symbol"
    ).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@app.get("/api/stocks/<symbol>")
def stock_detail(symbol):
    """Bir hissenin tüm detayını döndürür: fiyat serisi, göstergeler, yorum, temel veriler."""
    symbol = symbol.upper()
    range_key = request.args.get("range", "3A")
    days = RANGE_DAYS.get(range_key, 90)

    conn = get_connection()
    stock = conn.execute("SELECT * FROM stocks WHERE symbol = ?", (symbol,)).fetchone()
    if stock is None:
        conn.close()
        return jsonify({"error": "Hisse bulunamadı"}), 404

    hist_rows = conn.execute(
        "SELECT date, close FROM price_history WHERE symbol = ? ORDER BY date ASC",
        (symbol,),
    ).fetchall()
    conn.close()

    dates = [r["date"] for r in hist_rows]
    closes = [r["close"] for r in hist_rows]

    sma20 = sma(closes, 20)
    sma50 = sma(closes, 50)
    rsi14 = rsi(closes, 14)
    macd_data = macd(closes)

    n = len(closes)
    short_term = interpret_short_term(
        rsi_last=rsi14[-1] if n else None,
        macd_last=macd_data["macd_line"][-1] if n else None,
        signal_last=macd_data["signal_line"][-1] if n else None,
        hist_prev=macd_data["hist"][-2] if n > 1 else None,
        hist_last=macd_data["hist"][-1] if n else None,
    )
    long_term = interpret_long_term(
        price=closes[-1] if n else None,
        ma50=sma50[-1] if n else None,
        ma50_prev=sma50[-6] if n > 6 else None,
        w52_low=stock["week52_low"],
        w52_high=stock["week52_high"],
    )

    # Sadece istenen aralığı grafiğe döndür (göstergeler her zaman tam
    # seri üzerinden hesaplanır, yalnızca görünen kısım kesilir)
    start = max(0, n - days)
    chart = [
        {"date": dates[i], "price": closes[i], "ma20": sma20[i], "ma50": sma50[i]}
        for i in range(start, n)
    ]

    return jsonify({
        "symbol": stock["symbol"],
        "name": stock["name"],
        "sector": stock["sector"],
        "last_price": stock["last_price"],
        "prev_close": stock["prev_close"],
        "change_pct": stock["change_pct"],
        "market_cap": stock["market_cap"],
        "pe_ratio": stock["pe_ratio"],
        "dividend_yield": stock["dividend_yield"],
        "week52_low": stock["week52_low"],
        "week52_high": stock["week52_high"],
        "updated_at": stock["updated_at"],
        "chart": chart,
        "short_term": short_term,
        "long_term": long_term,
    })


@app.get("/api/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(debug=True, port=8000)
