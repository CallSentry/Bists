"""
Günlük veri toplama scripti.

Bu script günde 1 kez (örn. borsa kapanışından sonra) çalıştırılacak
şekilde tasarlanmıştır. borsapy ile tüm BIST hisselerinin son 1 yıllık
kapanış verisini ve temel şirket bilgilerini çekip yerel bir SQLite
veritabanına yazar. API katmanı (api.py) sadece bu veritabanını okur,
her istekte borsapy'ye gitmez — böylece hızlı ve ücretsiz limitler
içinde kalır.

Render'da bir "Cron Job" olarak günde 1 kez tetiklenecek şekilde
kurulması önerilir (bkz. README.md).
"""

import sqlite3
import time
import traceback
from datetime import datetime, timezone

import borsapy as bp

DB_PATH = "bist_data.db"


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL;")
    return conn


def init_db(conn):
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS stocks (
            symbol TEXT PRIMARY KEY,
            name TEXT,
            sector TEXT,
            last_price REAL,
            prev_close REAL,
            change_pct REAL,
            market_cap REAL,
            pe_ratio REAL,
            dividend_yield REAL,
            free_float REAL,
            week52_low REAL,
            week52_high REAL,
            updated_at TEXT
        );

        CREATE TABLE IF NOT EXISTS price_history (
            symbol TEXT,
            date TEXT,
            close REAL,
            volume REAL,
            PRIMARY KEY (symbol, date)
        );

        CREATE TABLE IF NOT EXISTS fetch_log (
            run_at TEXT,
            total INTEGER,
            success INTEGER,
            failed INTEGER,
            note TEXT
        );
        """
    )
    conn.commit()


def get_all_symbols():
    """Tüm BIST şirketlerinin sembol listesini döndürür."""
    df = bp.companies()
    # borsapy 'symbol' sütununu döndürür; kolon adı sürüme göre
    # değişebilir, ihtiyaten kontrol ediyoruz.
    col = "symbol" if "symbol" in df.columns else df.columns[0]
    return sorted(df[col].dropna().unique().tolist())


def fetch_one(symbol: str):
    """Tek bir hissenin fiyat geçmişini ve temel verilerini çeker."""
    ticker = bp.Ticker(symbol)

    hist = ticker.history(period="1y")
    if hist is None or len(hist) == 0:
        raise ValueError(f"{symbol} için fiyat geçmişi bulunamadı")

    fast = ticker.fast_info or {}
    info = {}
    try:
        info = ticker.info or {}
    except Exception:
        pass  # detaylı info bazı semboller için sınırlı olabilir

    last_price = fast.get("last_price")
    prev_close = fast.get("previous_close")
    change_pct = None
    if last_price is not None and prev_close:
        change_pct = round((last_price - prev_close) / prev_close * 100, 2)

    closes = hist["close"].tolist() if "close" in hist.columns else hist["Close"].tolist()
    week52_low = min(closes[-252:]) if closes else None
    week52_high = max(closes[-252:]) if closes else None

    return {
        "symbol": symbol,
        "name": info.get("longName") or info.get("shortName") or symbol,
        "sector": info.get("sector"),
        "last_price": last_price,
        "prev_close": prev_close,
        "change_pct": change_pct,
        "market_cap": fast.get("market_cap") or info.get("marketCap"),
        "pe_ratio": fast.get("pe_ratio") or info.get("trailingPE"),
        "dividend_yield": info.get("dividendYield"),
        "free_float": fast.get("free_float"),
        "week52_low": week52_low,
        "week52_high": week52_high,
        "history": hist,
    }


def save_stock(conn, data):
    conn.execute(
        """
        INSERT INTO stocks (symbol, name, sector, last_price, prev_close, change_pct,
                             market_cap, pe_ratio, dividend_yield, free_float,
                             week52_low, week52_high, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(symbol) DO UPDATE SET
            name=excluded.name, sector=excluded.sector, last_price=excluded.last_price,
            prev_close=excluded.prev_close, change_pct=excluded.change_pct,
            market_cap=excluded.market_cap, pe_ratio=excluded.pe_ratio,
            dividend_yield=excluded.dividend_yield, free_float=excluded.free_float,
            week52_low=excluded.week52_low, week52_high=excluded.week52_high,
            updated_at=excluded.updated_at
        """,
        (
            data["symbol"], data["name"], data["sector"], data["last_price"],
            data["prev_close"], data["change_pct"], data["market_cap"],
            data["pe_ratio"], data["dividend_yield"], data["free_float"],
            data["week52_low"], data["week52_high"],
            datetime.now(timezone.utc).isoformat(),
        ),
    )

    hist = data["history"]
    close_col = "close" if "close" in hist.columns else "Close"
    vol_col = "volume" if "volume" in hist.columns else "Volume"
    rows = [
        (data["symbol"], str(idx.date()) if hasattr(idx, "date") else str(idx),
         float(row[close_col]), float(row.get(vol_col, 0) or 0))
        for idx, row in hist.iterrows()
    ]
    conn.executemany(
        "INSERT OR REPLACE INTO price_history (symbol, date, close, volume) VALUES (?, ?, ?, ?)",
        rows,
    )


def run():
    conn = get_connection()
    init_db(conn)

    symbols = get_all_symbols()
    print(f"Toplam {len(symbols)} sembol bulundu.")

    success, failed = 0, 0
    for i, symbol in enumerate(symbols, 1):
        try:
            data = fetch_one(symbol)
            save_stock(conn, data)
            conn.commit()
            success += 1
        except Exception as exc:
            failed += 1
            print(f"[HATA] {symbol}: {exc}")
            traceback.print_exc()
        finally:
            # TradingView tabanlı veri kaynağına saygılı bir hız sınırı
            time.sleep(0.3)

        if i % 25 == 0:
            print(f"{i}/{len(symbols)} işlendi...")

    conn.execute(
        "INSERT INTO fetch_log (run_at, total, success, failed, note) VALUES (?, ?, ?, ?, ?)",
        (datetime.now(timezone.utc).isoformat(), len(symbols), success, failed, ""),
    )
    conn.commit()
    conn.close()
    print(f"Bitti. Başarılı: {success}, Başarısız: {failed}")


if __name__ == "__main__":
    run()
