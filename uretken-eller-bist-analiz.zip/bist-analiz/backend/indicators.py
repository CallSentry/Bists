"""
Teknik gösterge hesaplamaları ve kural tabanlı kısa/uzun vade yorumu.

Bu modül ham kapanış fiyatı listesinden (en eski -> en yeni sıralı)
SMA, EMA, RSI ve MACD hesaplar; ardından bu göstergeleri "Olumlu /
Nötr / Olumsuz" etiketli, gerekçeli bir yoruma çevirir.

ÖNEMLİ: Bu bir alım/satım tavsiyesi motoru değildir. Sadece seçilen
göstergelerin durumunu şeffaf biçimde özetler.
"""

from typing import List, Optional


def sma(values: List[float], period: int) -> List[Optional[float]]:
    out = []
    for i in range(len(values)):
        if i < period - 1:
            out.append(None)
        else:
            window = values[i - period + 1 : i + 1]
            out.append(round(sum(window) / period, 4))
    return out


def ema(values: List[float], period: int) -> List[float]:
    if not values:
        return []
    k = 2 / (period + 1)
    out = [values[0]]
    for v in values[1:]:
        out.append(round(v * k + out[-1] * (1 - k), 6))
    return out


def rsi(values: List[float], period: int = 14) -> List[Optional[float]]:
    out: List[Optional[float]] = [None] * len(values)
    if len(values) < period + 1:
        return out

    gains = 0.0
    losses = 0.0
    for i in range(1, len(values)):
        diff = values[i] - values[i - 1]
        gain = max(diff, 0)
        loss = max(-diff, 0)
        if i <= period:
            gains += gain
            losses += loss
            if i == period:
                avg_gain = gains / period
                avg_loss = losses / period
                rs = avg_gain / (avg_loss or 1e-9)
                out[i] = round(100 - 100 / (1 + rs), 2)
                gains, losses = avg_gain, avg_loss
        else:
            gains = (gains * (period - 1) + gain) / period
            losses = (losses * (period - 1) + loss) / period
            rs = gains / (losses or 1e-9)
            out[i] = round(100 - 100 / (1 + rs), 2)
    return out


def macd(values: List[float]):
    ema12 = ema(values, 12)
    ema26 = ema(values, 26)
    macd_line = [round(a - b, 4) for a, b in zip(ema12, ema26)]
    signal_line = ema(macd_line, 9)
    hist = [round(a - b, 4) for a, b in zip(macd_line, signal_line)]
    return {"macd_line": macd_line, "signal_line": signal_line, "hist": hist}


def interpret_short_term(rsi_last, macd_last, signal_last, hist_prev, hist_last):
    reasons = []
    score = 0.0

    if rsi_last is None:
        reasons.append({"text": "RSI için yeterli veri yok", "tone": "neutral"})
    elif rsi_last >= 70:
        reasons.append({"text": f"RSI {rsi_last:.0f} — aşırı alım bölgesinde, kısa vadeli geri çekilme riski var", "tone": "down"})
        score -= 1
    elif rsi_last <= 30:
        reasons.append({"text": f"RSI {rsi_last:.0f} — aşırı satım bölgesinde, tepki alımı ihtimali var", "tone": "up"})
        score += 1
    else:
        reasons.append({"text": f"RSI {rsi_last:.0f} — nötr bölgede, belirgin bir aşırılık yok", "tone": "neutral"})

    if macd_last is not None and signal_last is not None:
        if macd_last > signal_last:
            reasons.append({"text": "MACD, sinyal çizgisinin üzerinde — kısa vadeli momentum pozitif", "tone": "up"})
            score += 1
        else:
            reasons.append({"text": "MACD, sinyal çizgisinin altında — kısa vadeli momentum negatif", "tone": "down"})
            score -= 1

    if hist_prev is not None and hist_last is not None:
        if hist_last > hist_prev:
            reasons.append({"text": "MACD histogramı genişliyor — momentum güçleniyor", "tone": "up"})
            score += 0.5
        else:
            reasons.append({"text": "MACD histogramı daralıyor — momentum zayıflıyor", "tone": "down"})
            score -= 0.5

    label, tone = "Nötr", "neutral"
    if score >= 1:
        label, tone = "Olumlu", "up"
    elif score <= -1:
        label, tone = "Olumsuz", "down"

    return {"label": label, "tone": tone, "reasons": reasons}


def interpret_long_term(price, ma50, ma50_prev, w52_low, w52_high):
    reasons = []
    score = 0.0

    if ma50 is None:
        reasons.append({"text": "MA50 için yeterli veri yok", "tone": "neutral"})
    else:
        if price > ma50:
            reasons.append({"text": "Fiyat, 50 günlük ortalamanın üzerinde — orta-uzun vadeli trend yukarı yönlü", "tone": "up"})
            score += 1
        else:
            reasons.append({"text": "Fiyat, 50 günlük ortalamanın altında — orta-uzun vadeli trend baskı altında", "tone": "down"})
            score -= 1

        if ma50_prev is not None:
            if ma50 > ma50_prev:
                reasons.append({"text": "50 günlük ortalama yükseliyor — trend eğimi pozitif", "tone": "up"})
                score += 0.5
            else:
                reasons.append({"text": "50 günlük ortalama düşüyor — trend eğimi negatif", "tone": "down"})
                score -= 0.5

    if w52_low is not None and w52_high is not None and w52_high > w52_low:
        pos = (price - w52_low) / (w52_high - w52_low)
        if pos > 0.75:
            reasons.append({"text": "Fiyat, 52 haftalık aralığın üst bölgesinde — güçlü konum ama tepe riskine dikkat", "tone": "neutral"})
        elif pos < 0.25:
            reasons.append({"text": "Fiyat, 52 haftalık aralığın alt bölgesinde — zayıf konum", "tone": "down"})
            score -= 0.5
        else:
            reasons.append({"text": "Fiyat, 52 haftalık aralığın orta kesiminde seyrediyor", "tone": "neutral"})

    label, tone = "Nötr", "neutral"
    if score >= 1:
        label, tone = "Olumlu", "up"
    elif score <= -1:
        label, tone = "Olumsuz", "down"

    return {"label": label, "tone": tone, "reasons": reasons}
