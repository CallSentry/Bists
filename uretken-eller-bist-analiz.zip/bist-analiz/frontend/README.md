# Frontend — Vercel'e Deploy Etme

## 1. Yerelde deneme (opsiyonel)

Node.js kuruluysa:

```bash
cd frontend
npm install
npm run dev
```

Tarayıcıda `http://localhost:5173` açılır. `src/App.jsx` içindeki
`API_BASE` değişkeni backend adresine işaret etmeli — yerelde
çalışıyorsan backend'i de `python api.py` ile ayrı bir terminalde
çalıştır (varsayılan `http://localhost:8000`).

## 2. Vercel'e deploy etme

1. [vercel.com](https://vercel.com) adresine GitHub hesabınla giriş yap.
2. **Add New → Project**, backend için kullandığın GitHub repo'sunu seç.
3. Ayarlar:
   - **Root Directory:** `frontend`
   - **Framework Preset:** Vite (otomatik algılanır)
   - **Build Command:** `npm run build` (varsayılan)
   - **Output Directory:** `dist` (varsayılan)
4. **Environment Variables** bölümüne ekle:
   - `VITE_API_BASE` = Render'da aldığın backend adresi
     (örn. `https://uretken-eller-bist-api.onrender.com`)
5. **Deploy**'a bas. Birkaç dakika içinde `https://senin-projen.vercel.app`
   adresinde canlıya alınır.

## 3. Arkadaşlarınla paylaşma

Vercel'in verdiği link'i doğrudan paylaşabilirsin. Herkese açık değil
sadece linki bilenler görsün istiyorsan, Vercel'in ücretsiz
katmanındaki "Password Protection" özelliği Pro plana bağlı — o
yüzden en pratik yol linki sadece grup içinde paylaşmak.

## Sorun giderme

- **Sayfa açılıyor ama veri gelmiyor:** `VITE_API_BASE` adresini
  tarayıcıda doğrudan `/api/stocks` ekleyerek dene (örn.
  `https://...onrender.com/api/stocks`). JSON dönmüyorsa backend'de
  ya da cron job'da bir sorun var demektir.
- **CORS hatası (konsolda kırmızı yazı):** `backend/api.py` içindeki
  `CORS(app)` satırının çalıştığından emin ol; gerekirse Render'da
  servisi yeniden başlat.
- **Render ücretsiz katmanda backend "uyuyabilir":** Uzun süre istek
  gelmezse ücretsiz Render servisleri uykuya geçer, ilk istek 30-60
  saniye gecikebilir. Bu normal, ücretli plana geçmeden çözülemez.
