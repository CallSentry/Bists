import React, { useState, useMemo, useEffect } from "react";
import {
  ComposedChart, Line, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer
} from "recharts";
import { Search, Star, TrendingUp, TrendingDown, Info, Loader2 } from "lucide-react";

// Render'a deploy ettiğin backend adresini buraya (veya Vercel'de bir
// ortam değişkeni olarak VITE_API_BASE) yaz. Örn:
// https://uretken-eller-bist-api.onrender.com
const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:8000";

const RANGES = { "1A": "1A", "3A": "3A", "1Y": "1Y" };

function Pill({ children, tone }) {
  const tones = {
    up: "bg-[#2FBF8F]/15 text-[#2FBF8F]",
    down: "bg-[#F0654B]/15 text-[#F0654B]",
    neutral: "bg-[#8B8FA3]/15 text-[#8B8FA3]",
  };
  return (
    <span className={`px-2 py-0.5 rounded text-[11px] font-mono tracking-wide ${tones[tone]}`}>
      {children}
    </span>
  );
}

function useWatchlist() {
  const [watch, setWatch] = useState(() => {
    try {
      const raw = localStorage.getItem("bist-watchlist");
      return raw ? new Set(JSON.parse(raw)) : new Set();
    } catch {
      return new Set();
    }
  });

  useEffect(() => {
    localStorage.setItem("bist-watchlist", JSON.stringify([...watch]));
  }, [watch]);

  const toggle = (code) =>
    setWatch((prev) => {
      const next = new Set(prev);
      next.has(code) ? next.delete(code) : next.add(code);
      return next;
    });

  return [watch, toggle];
}

export default function App() {
  const [stocks, setStocks] = useState([]);
  const [loadingList, setLoadingList] = useState(true);
  const [listError, setListError] = useState(null);

  const [active, setActive] = useState(null);
  const [detail, setDetail] = useState(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [detailError, setDetailError] = useState(null);

  const [range, setRange] = useState("3A");
  const [showMA, setShowMA] = useState(true);
  const [query, setQuery] = useState("");
  const [watch, toggleWatch] = useWatchlist();

  // Hisse listesini çek
  useEffect(() => {
    setLoadingList(true);
    fetch(`${API_BASE}/api/stocks`)
      .then((r) => {
        if (!r.ok) throw new Error(`Sunucu hatası: ${r.status}`);
        return r.json();
      })
      .then((data) => {
        setStocks(data);
        setListError(null);
        if (data.length > 0) setActive((prev) => prev || data[0].symbol);
      })
      .catch((err) => setListError(err.message))
      .finally(() => setLoadingList(false));
  }, []);

  // Seçili hissenin detayını çek
  useEffect(() => {
    if (!active) return;
    setLoadingDetail(true);
    fetch(`${API_BASE}/api/stocks/${active}?range=${range}`)
      .then((r) => {
        if (!r.ok) throw new Error(`Sunucu hatası: ${r.status}`);
        return r.json();
      })
      .then((data) => {
        setDetail(data);
        setDetailError(null);
      })
      .catch((err) => setDetailError(err.message))
      .finally(() => setLoadingDetail(false));
  }, [active, range]);

  const filtered = useMemo(
    () =>
      stocks.filter(
        (s) =>
          s.symbol.toLowerCase().includes(query.toLowerCase()) ||
          (s.name || "").toLowerCase().includes(query.toLowerCase())
      ),
    [stocks, query]
  );

  if (listError) {
    return (
      <div className="min-h-screen bg-[#12141A] text-[#E8E9ED] flex items-center justify-center p-6">
        <div className="max-w-md text-center space-y-2">
          <p className="text-[#F0654B] font-mono text-sm">Veriye ulaşılamadı: {listError}</p>
          <p className="text-[#8B8FA3] text-sm">
            Backend adresinin (API_BASE) doğru ve çalışır durumda olduğundan emin ol.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full bg-[#12141A] text-[#E8E9ED] font-sans">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500;600&display=swap');
        .font-sans { font-family: 'Inter', sans-serif; }
        .font-display { font-family: 'Space Grotesk', sans-serif; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
      `}</style>

      {/* Ticker tape */}
      <div className="border-b border-[#2A2E3A] bg-[#0E1015] overflow-hidden">
        <div className="flex gap-8 px-4 py-2 overflow-x-auto">
          {loadingList ? (
            <span className="text-[12px] font-mono text-[#8B8FA3] flex items-center gap-2">
              <Loader2 size={12} className="animate-spin" /> Veriler yükleniyor…
            </span>
          ) : (
            stocks.slice(0, 40).map((s) => {
              const pos = (s.change_pct ?? 0) >= 0;
              return (
                <div key={s.symbol} className="flex items-center gap-2 shrink-0 font-mono text-[12px]">
                  <span className="text-[#8B8FA3]">{s.symbol}</span>
                  <span className={pos ? "text-[#2FBF8F]" : "text-[#F0654B]"}>
                    {pos ? "▲" : "▼"} {Math.abs(s.change_pct ?? 0).toFixed(2)}%
                  </span>
                </div>
              );
            })
          )}
        </div>
      </div>

      <div className="max-w-[1200px] mx-auto px-5 py-6 grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-6">
        {/* Sidebar */}
        <aside className="space-y-4">
          <div>
            <h1 className="font-display text-xl font-700 tracking-tight">Üretken Eller — BİST Panosu</h1>
            <p className="text-[13px] text-[#8B8FA3] mt-0.5">Kişisel izleme listesi</p>
          </div>

          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5B5F70]" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Hisse ara (kod veya isim)"
              className="w-full bg-[#1A1D26] border border-[#2A2E3A] rounded-md pl-8 pr-3 py-2 text-[13px] font-mono outline-none focus:border-[#D4A537] placeholder:text-[#5B5F70]"
            />
          </div>

          <div className="space-y-1 max-h-[70vh] overflow-y-auto pr-1">
            {filtered.map((s) => {
              const pos = (s.change_pct ?? 0) >= 0;
              const isActive = s.symbol === active;
              return (
                <button
                  key={s.symbol}
                  onClick={() => setActive(s.symbol)}
                  className={`w-full flex items-center justify-between gap-2 rounded-md px-2.5 py-2 text-left transition-colors ${
                    isActive ? "bg-[#1E2230] border border-[#D4A537]/40" : "border border-transparent hover:bg-[#1A1D26]"
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <button
                      onClick={(e) => { e.stopPropagation(); toggleWatch(s.symbol); }}
                      className="shrink-0"
                      aria-label="izleme listesine ekle"
                    >
                      <Star size={13} className={watch.has(s.symbol) ? "fill-[#D4A537] text-[#D4A537]" : "text-[#3A3E4D]"} />
                    </button>
                    <div className="min-w-0">
                      <div className="font-mono text-[13px] leading-tight">{s.symbol}</div>
                      <div className="text-[11px] text-[#8B8FA3] truncate leading-tight">{s.name}</div>
                    </div>
                  </div>
                  <span className={`font-mono text-[11px] w-14 text-right shrink-0 ${pos ? "text-[#2FBF8F]" : "text-[#F0654B]"}`}>
                    {pos ? "+" : ""}{(s.change_pct ?? 0).toFixed(1)}%
                  </span>
                </button>
              );
            })}
          </div>

          <div className="rounded-md border border-[#2A2E3A] bg-[#1A1D26] p-3 flex gap-2 items-start">
            <Info size={14} className="text-[#8B8FA3] mt-0.5 shrink-0" />
            <p className="text-[11px] text-[#8B8FA3] leading-relaxed">
              Veriler günde bir kez, borsa kapanışından sonra güncellenir.
              Bu sayfadaki hiçbir içerik yatırım tavsiyesi değildir.
            </p>
          </div>
        </aside>

        {/* Main panel */}
        <main className="space-y-5">
          {loadingDetail || !detail ? (
            <div className="h-64 flex items-center justify-center text-[#8B8FA3] text-sm gap-2">
              <Loader2 size={16} className="animate-spin" /> Yükleniyor…
            </div>
          ) : detailError ? (
            <p className="text-[#F0654B] text-sm">{detailError}</p>
          ) : (
            <>
              <div className="flex flex-wrap items-end justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="font-display text-2xl font-700 tracking-tight">{detail.symbol}</h2>
                    {detail.sector && <Pill tone="neutral">{detail.sector}</Pill>}
                  </div>
                  <p className="text-[13px] text-[#8B8FA3] mt-0.5">{detail.name}</p>
                </div>
                <div className="text-right">
                  <div className="font-mono text-3xl font-600">{detail.last_price?.toFixed(2)} ₺</div>
                  <div className={`font-mono text-[13px] flex items-center gap-1 justify-end ${
                    (detail.change_pct ?? 0) >= 0 ? "text-[#2FBF8F]" : "text-[#F0654B]"
                  }`}>
                    {(detail.change_pct ?? 0) >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                    {(detail.change_pct ?? 0) >= 0 ? "+" : ""}{(detail.change_pct ?? 0).toFixed(2)}%
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex gap-1 bg-[#1A1D26] border border-[#2A2E3A] rounded-md p-1">
                  {Object.keys(RANGES).map((r) => (
                    <button
                      key={r}
                      onClick={() => setRange(r)}
                      className={`px-3 py-1 text-[12px] font-mono rounded ${
                        range === r ? "bg-[#D4A537] text-[#12141A]" : "text-[#8B8FA3] hover:text-[#E8E9ED]"
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setShowMA((v) => !v)}
                  className={`text-[12px] font-mono px-3 py-1.5 rounded-md border ${
                    showMA ? "border-[#D4A537]/50 text-[#D4A537] bg-[#D4A537]/10" : "border-[#2A2E3A] text-[#8B8FA3]"
                  }`}
                >
                  MA 20 / 50
                </button>
              </div>

              <div className="rounded-lg border border-[#2A2E3A] bg-[#1A1D26] p-4">
                <ResponsiveContainer width="100%" height={280}>
                  <ComposedChart data={detail.chart}>
                    <defs>
                      <linearGradient id="priceFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#D4A537" stopOpacity={0.25} />
                        <stop offset="100%" stopColor="#D4A537" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid stroke="#2A2E3A" strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="date" tick={false} axisLine={{ stroke: "#2A2E3A" }} />
                    <YAxis
                      domain={["auto", "auto"]}
                      tick={{ fill: "#8B8FA3", fontSize: 11, fontFamily: "JetBrains Mono" }}
                      axisLine={false} tickLine={false} width={50}
                    />
                    <Tooltip
                      contentStyle={{ background: "#0E1015", border: "1px solid #2A2E3A", borderRadius: 6, fontSize: 12, fontFamily: "JetBrains Mono" }}
                    />
                    <Area type="monotone" dataKey="price" stroke="#D4A537" strokeWidth={2} fill="url(#priceFill)" dot={false} />
                    {showMA && <Line type="monotone" dataKey="ma20" stroke="#5B9FD4" strokeWidth={1.3} dot={false} />}
                    {showMA && <Line type="monotone" dataKey="ma50" stroke="#B37FE0" strokeWidth={1.3} dot={false} />}
                  </ComposedChart>
                </ResponsiveContainer>
                {showMA && (
                  <div className="flex gap-4 mt-2 pl-2">
                    <span className="text-[11px] font-mono text-[#5B9FD4] flex items-center gap-1.5">
                      <span className="w-2.5 h-0.5 bg-[#5B9FD4] inline-block" /> MA 20
                    </span>
                    <span className="text-[11px] font-mono text-[#B37FE0] flex items-center gap-1.5">
                      <span className="w-2.5 h-0.5 bg-[#B37FE0] inline-block" /> MA 50
                    </span>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { title: "Kısa Vade Görünüm", sub: "RSI + MACD momentum", data: detail.short_term },
                  { title: "Uzun Vade Görünüm", sub: "MA50 trend + 52 hafta konumu", data: detail.long_term },
                ].map(({ title, sub, data }) => (
                  <div key={title} className="rounded-lg border border-[#2A2E3A] bg-[#1A1D26] p-4">
                    <div className="flex items-center justify-between mb-1">
                      <div>
                        <div className="text-[13px] font-display font-600">{title}</div>
                        <div className="text-[11px] text-[#8B8FA3]">{sub}</div>
                      </div>
                      <Pill tone={data.tone}>{data.label}</Pill>
                    </div>
                    <ul className="mt-3 space-y-2">
                      {data.reasons.map((r, i) => (
                        <li key={i} className="flex items-start gap-2 text-[12px] text-[#C7C9D4] leading-relaxed">
                          <span className={`mt-1.5 w-1.5 h-1.5 rounded-full shrink-0 ${
                            r.tone === "up" ? "bg-[#2FBF8F]" : r.tone === "down" ? "bg-[#F0654B]" : "bg-[#8B8FA3]"
                          }`} />
                          {r.text}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
              <p className="text-[11px] text-[#8B8FA3] flex items-start gap-1.5 -mt-2">
                <Info size={12} className="mt-0.5 shrink-0" />
                Bu yorumlar seçilen teknik göstergelerin kural tabanlı bir özetidir; alım/satım tavsiyesi değildir.
              </p>

              <div className="rounded-lg border border-[#2A2E3A] bg-[#1A1D26] p-4">
                <span className="text-[12px] font-mono text-[#8B8FA3]">Temel Veriler</span>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 mt-3">
                  {[
                    ["F/K", detail.pe_ratio?.toFixed(1) ?? "—"],
                    ["Piyasa Değeri", detail.market_cap ? `${(detail.market_cap / 1e9).toFixed(1)} Mlr ₺` : "—"],
                    ["Temettü Verimi", detail.dividend_yield ? `%${detail.dividend_yield.toFixed(1)}` : "—"],
                    ["52H Düşük", detail.week52_low ? `${detail.week52_low.toFixed(2)} ₺` : "—"],
                    ["52H Yüksek", detail.week52_high ? `${detail.week52_high.toFixed(2)} ₺` : "—"],
                  ].map(([label, val]) => (
                    <div key={label}>
                      <div className="text-[11px] text-[#8B8FA3]">{label}</div>
                      <div className="font-mono text-[14px] mt-0.5">{val}</div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </main>
      </div>
    </div>
  );
}
